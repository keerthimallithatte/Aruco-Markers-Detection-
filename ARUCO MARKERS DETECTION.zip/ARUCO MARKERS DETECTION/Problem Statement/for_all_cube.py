import numpy as np
import cv2
import cv2.aruco as aruco
import math
"""
**************************************************************************
*                  E-Yantra Robotics Competition
*                  ================================
*  This software is intended to check version compatiability of open source software
*  Theme: Thirsty Crow
*  MODULE: Task1.1
*  Filename: detect.py
*  Version: 1.0.0  
*  Date: October 31, 2018
*  
*  Author: e-Yantra Project, Department of Computer Science
*  and Engineering, Indian Institute of Technology Bombay.
*  
*  Software released under Creative Commons CC BY-NC-SA
*
*  For legal information refer to:
*        http://creativecommons.org/licenses/by-nc-sa/4.0/legalcode 
*     
*
*  This software is made available on an “AS IS WHERE IS BASIS”. 
*  Licensee/end user indemnifies and will keep e-Yantra indemnified from
*  any and all claim(s) that emanate from the use of the Software or 
*  breach of the terms of this agreement.
*  
*  e-Yantra - An MHRD project under National Mission on Education using 
*  ICT(NMEICT)
*
**************************************************************************
"""

####################### Define Utility Functions Here ##########################
"""
Function Name : getCameraMatrix()
Input: None
Output: camera_matrix, dist_coeff
Purpose: Loads the camera calibration file provided and returns the camera and
         distortion matrix saved in the calibration file.
"""
def getCameraMatrix():
	with np.load('System.npz') as X:
		camera_matrix, dist_coeff, _, _ = [X[i] for i in ('mtx','dist','rvecs','tvecs')]
	return camera_matrix, dist_coeff

"""
Function Name : sin()
Input: angle (in degrees)
Output: value of sine of angle specified
Purpose: Returns the sine of angle specified in degrees
"""
def sin(angle):
	return math.sin(math.radians(angle))

"""
Function Name : cos()
Input: angle (in degrees)
Output: value of cosine of angle specified
Purpose: Returns the cosine of angle specified in degrees
"""
def cos(angle):
	return math.cos(math.radians(angle))



################################################################################


"""
Function Name : detect_markers()
Input: img (numpy array), camera_matrix, dist_coeff
Output: aruco list in the form [(aruco_id_1, centre_1, rvec_1, tvec_1),(aruco_id_2,
        centre_2, rvec_2, tvec_2), ()....]
Purpose: This function takes the image in form of a numpy array, camera_matrix and
         distortion matrix as input and detects ArUco markers in the image. For each
         ArUco marker detected in image, paramters such as ID, centre coord, rvec
         and tvec are calculated and stored in a list in a prescribed format. The list
         is returned as output for the function
"""
def detect_markers(img, camera_matrix, dist_coeff):
	markerLength = 100
	aruco_list = []
	gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
	aruco_dict = aruco.Dictionary_get(aruco.DICT_5X5_250)
	parameters = aruco.DetectorParameters_create()
	corners, ids, _ = aruco.detectMarkers(gray,aruco_dict,parameters =parameters)
	center= []
	aruco_list1=[]
	aruco_list2=[]
	for i in range(0,len(corners)):
		x1,y1=corners[i][0][0]
		x2,y2=corners[i][0][1]
		x3,y3=corners[i][0][2]
		x4,y4=corners[i][0][3]
		p1=(y2+y3)/2
		p2=(y1+y4)/2
		q1=(x1+x2)/2
		q2=(x3+x4)/2
		center=[(q1+q2)/2,(p1+p2)/2]
		'''img = cv2.line(img, (x1, y1), (x2, y2), (0, 255, 0), 1)
		img = cv2.line(img, (x2, y2), (x3, y3), (0, 255, 0), 1)
		img = cv2.line(img, (x4, y4), (x3, y3), (0, 255, 0), 1)
		img = cv2.line(img, (x4, y4), (x1, y1), (0, 255, 0), 1)'''
		rvec, tvec,_= aruco.estimatePoseSingleMarkers(corners, markerLength, camera_matrix, dist_coeff)
		if(i==0):
			aruco_list1=[ids[i][0], center, rvec[i], tvec[i]]
			aruco_list=[aruco_list1]
			#print(aruco_list)
		if(i==1):
			aruco_list2=[ids[i][0], center, rvec[i], tvec[i]]
			aruco_list=[aruco_list1,aruco_list2]
		if(i==2):
			aruco_list3=[ids[i][0], center, rvec[i], tvec[i]]
			aruco_list=[aruco_list1,aruco_list2,aruco_list3]
	print(aruco_list)
	return aruco_list

"""
Function Name : drawAxis()
Input: img (numpy array), aruco_list, aruco_id, camera_matrix, dist_coeff
Output: img (numpy array)
Purpose: This function takes the above specified outputs and draws 3 mutually
         perpendicular axes on the specified aruco aruco_list=[aruco_list,aruco_list1]
			print(aruco_list)marker in the image and
         returns the modified image.
"""
def drawAxis(img, aruco_list, aruco_id, camera_matrix, dist_coeff):
	'''for x in aruco_list:
		if aruco_id == x[0]:
			rvec, tvec = x[2], x[3]'''
	markerLength = 100
	m = markerLength/2
	for i in range(0,len(aruco_list)):
		rvec=aruco_list[i][2]
		tvec=aruco_list[i][3]
		pts = np.float32([[-m,m,0],[m,m,0],[-m,-m,0],[-m,m,m]])
		pt_dict = {}
		imgpts, _ = cv2.projectPoints(pts, rvec, tvec, camera_matrix, dist_coeff)
		print(imgpts)
		for i in range(len(pts)):
			 pt_dict[tuple(pts[i])] = tuple(imgpts[i].ravel())
		src = pt_dict[tuple(pts[0])];   dst1 = pt_dict[tuple(pts[1])];
		dst2 = pt_dict[tuple(pts[2])];  dst3 = pt_dict[tuple(pts[3])];
		#print(src,dst1,dst2,dst3)
		img = cv2.line(img, src, dst1, (0,255,0), 4)
		img = cv2.line(img, src, dst2, (255,0,0), 4)
		img = cv2.line(img, src, dst3, (0,0,255), 4)
	return img

"""
Function Name : drawCube()
Input: img (numpy array), aruco_list, aruco_id, camera_matrix, dist_coeff
Output: img (numpy array)
Purpose: This function takes the above specified outputs and draws a cube
         on the specified aruco marker in the image and returns the modified
         image.
"""
def drawCube(img, ar_list, ar_id, camera_matrix, dist_coeff):
	'''for x in ar_list:
		if ar_id == x[0]:
			rvec, tvec = x[2], x[3]'''
	markerLength = 100
	m = markerLength/2
	for i in range(0,len(aruco_list)):
		rvec=aruco_list[i][2]
		tvec=aruco_list[i][3]
		pts = np.float32([[-m,m,0],[m,m,0],[-m,-m,0],[-m,m,m]])
		pt_dict = {}
		imgpts, _ = cv2.projectPoints(pts, rvec, tvec, camera_matrix, dist_coeff)
		print(imgpts)
		for i in range(len(pts)):
			 pt_dict[tuple(pts[i])] = tuple(imgpts[i].ravel())
		src = pt_dict[tuple(pts[0])];   dst1 = pt_dict[tuple(pts[1])];
		dst2 = pt_dict[tuple(pts[2])];  dst3 = pt_dict[tuple(pts[3])];
		#print(src,dst1,dst2,dst3)
		img = cv2.line(img, src, dst1, (0,0,255), 4)
		img = cv2.line(img, src, dst2, (0,0,255), 4)
		img = cv2.line(img, src, dst3, (0,0,255), 4)
		pts1 = np.float32([[m,-m,0],[-m,-m,m],[m,-m,m],[m,m,m]])
		pt_dict = {}
		imgpts1, _ = cv2.projectPoints(pts1, rvec, tvec, camera_matrix, dist_coeff)
		print(imgpts1)
		for i in range(len(pts1)):
			 pt_dict[tuple(pts1[i])] = tuple(imgpts1[i].ravel())
		src1 = pt_dict[tuple(pts1[0])];   dst11 = pt_dict[tuple(pts1[1])];
		dst12 = pt_dict[tuple(pts1[2])];  dst13 = pt_dict[tuple(pts1[3])];
		#print(src,dst1,dst2,dst3)
		img = cv2.line(img, src1, dst12, (0,0,255), 4)
		img = cv2.line(img, dst13, dst12, (0,0,255), 4)
		img = cv2.line(img, dst11, dst12, (0,0,255), 4)
		img = cv2.line(img, dst2, src1, (0,0,255), 4)
		img = cv2.line(img, dst11, dst2, (0,0,255), 4)
		img = cv2.line(img, dst1, src1, (0,0,255), 4)
		#img = cv2.line(img, dst3, src1, (0,0,255), 4)
		img = cv2.line(img, dst11, dst3, (0,0,255), 4)
		img = cv2.line(img, dst13, dst3, (0,0,255), 4)
		img = cv2.line(img, dst1, dst13, (0,0,255), 4)
	return img

"""
Function Name : drawCylinder()
Input: img (numpy array), aruco_list, aruco_id, camera_matrix, dist_coeff
Output: img (numpy array)
Purpose: This function takes the above specified outputs and draws a cylinder
         on the specified aruco marker in the image and returns the modified
         image.
"""
def drawCylinder(img, aruco_list, aruco_id, camera_matrix, dist_coeff):
	markerLength = 100
	radius = int(markerLength/2); 
	r=radius
	height = markerLength*1.5
	h=height	
	for i in range(0,len(aruco_list)):
		rvec=aruco_list[i][2]
		tvec=aruco_list[i][3]
		cen = aruco_list[i][1]
		print(cen)
		img = cv2.circle(img, (int(cen[0]),int(cen[1])) , radius , (255,0,0), 3)
		pts = np.float32([[-h,h,0],[h,h,0],[-h,-h,0],[-h,h,h]])
		pt_dict = {}
		imgpts, _ = cv2.projectPoints(pts, rvec, tvec, camera_matrix, dist_coeff)
		print(imgpts)
		for i in range(len(pts)):
			 pt_dict[tuple(pts[i])] = tuple(imgpts[i].ravel())
		src = pt_dict[tuple(pts[0])];   dst1 = pt_dict[tuple(pts[1])];
		dst2 = pt_dict[tuple(pts[2])];  dst3 = pt_dict[tuple(pts[3])];
	
		pts1 = np.float32([[-r,r,0],[r,r,0],[-r,-r,0],[-r,r,r]])
		pt_dict = {}
		imgpts1, _ = cv2.projectPoints(pts1, rvec, tvec, camera_matrix, dist_coeff)
		print(imgpts1)
		for i in range(len(pts1)):
			 pt_dict[tuple(pts1[i])] = tuple(imgpts1[i].ravel())
		src1 = pt_dict[tuple(pts1[0])];   dst11 = pt_dict[tuple(pts1[1])];
		dst12 = pt_dict[tuple(pts1[2])];  dst13 = pt_dict[tuple(pts1[3])];
		a1=cen[0]+r
		b1=cen[0]-r
		c1=cen[1]+r
		d1=cen[1]-r
		a=src[0]+r
		b=src[0]-r
		c=src[1]+r
		d=src[1]-r
		img = cv2.circle(img, (int(src[0]),int(src[1])) , radius , (255,0,0), 3)
		img = cv2.line(img, (int(cen[0]),int(cen[1])), (int(src[0]),int(src[1])), (255,0,0), 3)
		img = cv2.line(img, (int(cen[0]),int(cen[1])), (int(a1),int(cen[1])), (255,0,0), 3)
		img = cv2.line(img, (int(cen[0]),int(cen[1])), (int(b1),int(cen[1])), (255,0,0), 3)
		img = cv2.line(img, (int(cen[0]),int(cen[1])), (int(cen[0]),int(c1)), (255,0,0), 3)
		img = cv2.line(img, (int(cen[0]),int(cen[1])), (int(cen[0]),int(d1)), (255,0,0), 3)
		img = cv2.line(img, (int(src[0]),int(src[1])), (int(a),int(src[1])), (255,0,0), 3)
		img = cv2.line(img, (int(src[0]),int(src[1])), (int(b),int(src[1])), (255,0,0), 3)
		img = cv2.line(img, (int(src[0]),int(src[1])), (int(src[0]),int(c)), (255,0,0), 3)
		img = cv2.line(img, (int(src[0]),int(src[1])), (int(src[0]),int(d)), (255,0,0), 3)
		img = cv2.line(img, (int(a1),int(cen[1])), (int(a),int(src[1])), (255,0,0), 3)
		img = cv2.line(img, (int(b1),int(cen[1])), (int(b),int(src[1])), (255,0,0), 3)
		img = cv2.line(img, (int(cen[0]),int(c1)), (int(src[0]),int(c)), (255,0,0), 3)
		img = cv2.line(img, (int(cen[0]),int(d1)), (int(src[0]),int(d)), (255,0,0), 3)
	return img

"""
MAIN CODE
This main code reads images from the test cases folder and converts them into
numpy array format using cv2.imread. Then it draws axis, cubes or cylinders on
the ArUco markers detected in the images.
"""


if __name__=="__main__":
	cam, dist = getCameraMatrix()
	img = cv2.imread("image_3.jpg")
	aruco_list = detect_markers(img, cam, dist)
	for i in aruco_list:
		img = drawAxis(img, aruco_list, i, cam, dist)
		img = drawCube(img, aruco_list, i, cam, dist)
		img = drawCylinder(img, aruco_list, i, cam, dist)
	cv2.imshow("img", img)
	cv2.waitKey(0)
	cv2.destroyAllWindows()
