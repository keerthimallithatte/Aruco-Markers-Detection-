import numpy as np
import cv2
import cv2.aruco as aruco
img=cv2.imread("image_1.jpg")
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
aruco_dict = aruco.Dictionary_get(aruco.DICT_5X5_250)
parameters = aruco.DetectorParameters_create()
corners, ids, _ = aruco.detectMarkers(gray,aruco_dict,parameters =parameters)
print(corners[0][0][0])
#print(corners[1])
x1,y1=corners[0][0][0]
x2,y2=corners[0][0][1]
x3,y3=corners[0][0][2]
x4,y4=corners[0][0][3]
p1=(y2+y3)/2
p2=(y1+y4)/2
q1=(x1+x2)/2
q2=(x3+x4)/2
center=[(q1+q2)/2,(p1+p2)/2]
#print(x1,y1)
print(ids)
print(center)
img = cv2.line(img, (x1, y1), (x2, y2), (0, 255, 0), 1)
img = cv2.line(img, (x2, y2), (x3, y3), (0, 255, 0), 1)
img = cv2.line(img, (x4, y4), (x3, y3), (0, 255, 0), 1)
img = cv2.line(img, (x4, y4), (x1, y1), (0, 255, 0), 1)
markerLength=100
with np.load('System.npz') as X:
	camera_matrix, dist_coeff,_,_=[X[i]for i in ('mtx','dist','rvecs','tvecs')]
rvec, tvec,_= aruco.estimatePoseSingleMarkers(corners, markerLength, camera_matrix, dist_coeff)
print(rvec)
print(tvec)
cv2.imwrite("imaggg.jpg", img)
cv2.imshow('frame',img)
cv2.waitKey(0)
cv2.destroyAllWindows()
